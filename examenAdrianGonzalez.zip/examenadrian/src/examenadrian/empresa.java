package examenadrian;

import java.time.LocalDateTime;

public class empresa {
	
	private String nombredeempresa;
	private int cif;
	private LocalDateTime fechadefundacion;
	private int nummaxtrabajadores;
	private String trabajador;
	
	empresa(String nombredeempresa,int cif,LocalDateTime fechadefundacion,int nummaxtrabajadores) {
	
	this.nombredeempresa = nombredeempresa;
	this.cif = cif;
	this.fechadefundacion = fechadefundacion;
	this.nummaxtrabajadores = nummaxtrabajadores;
	
	
	}

	public String getNombredeempresa() {
		return nombredeempresa;
	}

	public void setNombredeempresa(String nombredeempresa) {
		this.nombredeempresa = nombredeempresa;
	}

	public int getCif() {
		return cif;
	}

	public void setCif(int cif) {
		this.cif = cif;
	}

	public LocalDateTime getFechadefundacion() {
		return fechadefundacion;
	}

	public void setFechadefundacion(LocalDateTime fechadefundacion) {
		this.fechadefundacion = fechadefundacion;
	}

	public int getNummaxtrabajadores() {
		return nummaxtrabajadores;
	}

	public void setNummaxtrabajadores(int nummaxtrabajadores) {
		this.nummaxtrabajadores = nummaxtrabajadores;
	}

	public String getTrabajador() {
		return trabajador;
	}

	public void setTrabajador(String trabajador) {
		this.trabajador = trabajador;
	}

	public String mostrarInfoempresa() {
		
		String s = "" + nombredeempresa + " cif " +  cif + " fecha de fundacion " + fechadefundacion + " Nummax trabajadores " + nummaxtrabajadores;

		return s;
		}
	
}
