
public enum Departamento {

	informática, gestión, marketing
}
